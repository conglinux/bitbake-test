#
# BitBake Base Server Code
#
# Copyright (C) 2006 - 2007  Michael 'Mickey' Lauer
# Copyright (C) 2006 - 2008  Richard Purdie
# Copyright (C) 2013         Alexandru Damian
#
# SPDX-License-Identifier: GPL-2.0-only
#
